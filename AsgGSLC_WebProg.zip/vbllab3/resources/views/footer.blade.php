<style>
    .footer {
            position: fixed;
            left: 0;
            bottom: 0;
            height: 5%;
            width: 100%;
            background-color: rgb(48, 84, 132);
            color: white;
            text-align: center;
            font-family: Arial, Helvetica, sans-serif;
        }
</style>

<div class="footer">
    <br>
    @ 2022 Copyright || 2401961412 - Daniel Justine
</div>
