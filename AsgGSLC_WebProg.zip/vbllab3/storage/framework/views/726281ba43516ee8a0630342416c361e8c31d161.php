<?php $__env->startSection('title','Insert Movie'); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <div>
        <?php if($errors->any()): ?>
            <strong><?php echo e($errors->first()); ?></strong>
        <?php endif; ?>


        <h3>Insert Movie</h3>
        <form enctype="multipart/form-data" action="/movie" method="post">
            <?php echo csrf_field(); ?>
            <label for="imageInsert">Image</label>
            <input type="file" id="imageInsert" name="image">
            <label for="titleInsert">Title</label>
            <input id="titleInsert" type="text" name="title" placeholder="Title">
            <label for="descInsert">Description</label>
            <input id="descSInsert" type="text" name="description" placeholder="Description">
            <input type="submit" value="Insert">
        </form>
        <h3>Insert Episode</h3>
        <form enctype="multipart/form-data" action="/episode" method="POST">
            <?php echo csrf_field(); ?>
            <label for="movieIDInsert">Movie ID</label>
            <input type="text" name="movieID" id="movieIDInsert" placeholder="Movie ID">
            <label for="episodeInsert">Episode</label>
            <input id="episodeInsert" type="text" name="episode" placeholder="Episode">
            <label for="titleInsert">Title</label>
            <input id="titleInsert" type="text" name="title" placeholder="Title">
            <input type="submit" value="Insert">
        </form>
    </div>
</body>
</html>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\belajar\AsgGSLC_WebProg\resources\views/index.blade.php ENDPATH**/ ?>