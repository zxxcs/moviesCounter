<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title','Movie Counter'); ?> </title>
    <style>
        table, th, td{
            border: 1px solid black;
        }
    </style>
</head>
<body>
    <h1>Movie Counter</h1>
    <div>
        <table style="border-collapse: collapse">
            <thead>
                <th>ID</th>
                <th>Photo</th>
                <th>Title</th>
                <th>Description</th>
                <th>Episodes</th>
                <th>Action</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($movie->id); ?></td>
                        <td>
                            <img width="200px" height="200px" src="<?php echo e(Storage::url($movie->image)); ?>" alt="">
                        </td>
                        <td><?php echo e($movie->title); ?></td>
                        <td><?php echo e($movie->description); ?></td>
                        <td>
                            <?php $__currentLoopData = $movie->episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div><?php echo e($episode->episode); ?> : <?php echo e($episode->title); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <form action="/movie/<?php echo e($movie->id); ?>" method="POST">
                                <?php echo e(method_field('DELETE')); ?>

                                <?php echo csrf_field(); ?>
                                <input type="submit" value="Delete">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div>
       <a href="/insert">Click here to insert movie</a>
       <a href="/update">Click here to update the movies</a>
    </div>


<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\belajar\vbllab3\resources\views/home.blade.php ENDPATH**/ ?>