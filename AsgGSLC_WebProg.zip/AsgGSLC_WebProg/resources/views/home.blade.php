<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>@yield('title','Movie Counter') </title>
    <style>
        table, th, td{
            border: 1px solid black;
        }
    </style>
</head>
<body>
    <h1>Movie Counter</h1>
    <div>
        <table style="border-collapse: collapse">
            <thead>
                <th>ID</th>
                <th>Photo</th>
                <th>Title</th>
                <th>Description</th>
                <th>Episodes</th>
                <th>Action</th>
            </thead>
            <tbody>
                @foreach ($movies as $movie)
                    <tr>
                        <td>{{$movie->id}}</td>
                        <td>
                            <img width="200px" height="200px" src="{{Storage::url($movie->image)}}" alt="">
                        </td>
                        <td>{{$movie->title}}</td>
                        <td>{{$movie->description}}</td>
                        <td>
                            @foreach ($movie->episodes as $episode)
                                <div>{{$episode->episode}} : {{$episode->title}}</div>
                            @endforeach
                        </td>
                        <td>
                            <form action="/movie/{{$movie->id}}" method="POST">
                                {{method_field('DELETE')}}
                                @csrf
                                <input type="submit" value="Delete">
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div>
       <a href="/insert">Click here to insert movie</a>
       <a href="/update">Click here to update the movies</a>
    </div>
@extends('footer')
